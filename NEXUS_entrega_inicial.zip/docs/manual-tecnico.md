# NEXUS — Manual técnico y preparación para el examen H3

**Versión del documento:** borrador inicial basado en el archivo recibido `Program.cs`.  
**Proyecto:** NEXUS v1.0 — Ecos del Vacío.  
**Tecnología:** C# y .NET Framework 4.8, aplicación de consola.

> Criterio de precisión: los apartados se separan en (a) elementos observados en el código, y (b) ejemplos complementarios cuando una característica solicitada no aparece implementada.

## I. Arquitectura y programación orientada a objetos

### 1. Propósito y funcionamiento
NEXUS es un juego de exploración y supervivencia. El jugador controla un cadete que explora cinco zonas, administra energía y salud, encuentra objetos, combate contra entidades y debe completar objetivos antes de regresar al punto de extracción.

El punto de entrada está en `Program.Main`. Este método establece el título de la consola, instancia `JuegoNexus` y llama a `Iniciar()`.

### 2. Estructura y responsabilidades
Todas las clases principales están declaradas en `Program.cs`. Aunque están en un solo archivo, cumplen responsabilidades diferenciadas:

- `Program`: inicia la aplicación.
- `JuegoNexus`: coordina el bucle de juego, las zonas, exploración, desplazamiento, encuentros, inventario y final.
- `Personaje`: clase abstracta común para personajes con nombre, salud y ataque.
- `Cadete`: representa al jugador; administra energía, experiencia, escudos y daño recibido.
- `Entidad`: clase abstracta para seres que pueden presentarse y atacar.
- `Robot` y `Enemigo`: especializan el comportamiento de `Entidad`.
- `Objeto`: representa un artículo del inventario con nombre y descripción.
- `Inventario`: administra una `List<Objeto>`.
- `Zona`: contiene nombre y descripción de una ubicación.
- `Mision`: registra objetivos y valida si se puede completar la misión.

### 3. Relaciones entre objetos
`Cadete` hereda de `Personaje`. `Entidad` también hereda de `Personaje`; `Robot` y `Enemigo` heredan de `Entidad`. `JuegoNexus` contiene referencias a un `Cadete`, un `Inventario`, una `Mision` y una lista de zonas. `Inventario` mantiene una lista de objetos.

El diagrama de clases y el flujograma están en `docs/diagramas.mmd`. Puedes pegarlos en un visor Mermaid compatible para renderizarlos.

### 4. Estructurada frente a orientada a objetos
La programación estructurada organiza la solución principalmente mediante secuencias, decisiones, ciclos y funciones. La programación orientada a objetos agrupa datos y comportamientos en tipos con responsabilidades.

NEXUS combina ambas ideas: `JuegoNexus` usa `while`, `switch`, `if` y métodos para controlar el flujo, mientras que clases como `Cadete`, `Inventario` y `Mision` agrupan estado y operaciones.

## II. Fundamentos de clases y objetos

### 1. Clase, objeto e instanciación
Una clase define una estructura y comportamiento. Un objeto es una instancia concreta.

Ejemplo real de `Program.cs`:
```csharp
Cadete cadete = new Cadete(nombre.Trim());
```
`Cadete` es el tipo; `cadete` es la variable de referencia; `new Cadete(...)` crea el objeto e invoca el constructor.

### 2. Campos, propiedades y métodos
En `JuegoNexus`, `private Random azar = new Random();` y `private List<Zona> zonas = new List<Zona>();` son campos privados.
En `Cadete`, `Energia`, `Experiencia` y `Escudos` son propiedades con `private set`, de modo que otros objetos pueden leerlas pero no asignarlas directamente.
`GastarEnergia`, `RecibirDanio` y `MostrarEstado` son métodos.

### 3. Constructores
El constructor `Cadete(string nombre) : base(nombre, 100, 20)` inicializa energía en 70, experiencia en 0 y escudos en 0; también llama al constructor de la clase base para establecer nombre, salud y ataque.
`Robot()` y `Enemigo()` usan `base(...)` para enviar datos iniciales a `Entidad`.

No se observó sobrecarga de constructores en las clases principales revisadas. Sobrecarga significa definir varios constructores del mismo nombre con diferentes listas de parámetros.

### 4. Encapsulamiento y modificadores
- `public`: accesible desde otros tipos.
- `private`: accesible solo dentro de la clase que lo declara.
- `protected`: accesible en la clase y sus derivadas.
- `private set`: lectura pública y modificación restringida a la propia clase.
- `protected set`: modificación permitida a la clase y a clases derivadas.

Ejemplo: `public int Energia { get; private set; }` protege el cambio de energía. El juego llama a `GastarEnergia` o `RecuperarEnergia`, en vez de escribir directamente el valor desde cualquier clase.

### 5. `this` y `base`
`base` sí aparece en NEXUS: `Cadete` llama a `base(nombre, 100, 20)` y su método sobrescrito llama a `base.RecibirDanio(cantidad)` para reutilizar la lógica de `Personaje`.
No se observó uso explícito de `this` en el código revisado. Ejemplo complementario:
```csharp
public Zona(string nombre, string descripcion)
{
    this.Nombre = nombre;
    this.Descripcion = descripcion;
}
```
`this` se refiere al objeto actual y resulta útil cuando un parámetro tiene el mismo nombre que una propiedad.

## III. Herencia, polimorfismo e interfaces

### 1. Herencia
NEXUS contiene esta jerarquía:
- `Personaje` (abstracta) → `Cadete`
- `Personaje` (abstracta) → `Entidad` (abstracta) → `Robot` y `Enemigo`

La herencia permite reutilizar el nombre, la salud, el ataque y el tratamiento básico del daño definidos en `Personaje`.

### 2. `virtual`, `override` y polimorfismo
`Personaje.RecibirDanio` es `virtual`; `Cadete.RecibirDanio` es `override`. El cadete reduce el daño si tiene escudo y luego delega el cálculo final a `base.RecibirDanio`.

`Entidad` define `Presentarse()` y `Atacar(Cadete)` como abstractos. `Robot` y `Enemigo` los implementan de manera distinta. En `JuegoNexus`, la variable `Entidad entidad` puede referirse a un `Robot` o a un `Enemigo`; al ejecutar `entidad.Atacar(cadete)`, se invoca la implementación del objeto concreto. Eso es polimorfismo.

### 3. Clases y métodos abstractos
Una clase abstracta sirve como base y no se instancia directamente. `Personaje` y `Entidad` son abstractas. Los métodos abstractos declaran una obligación para las clases concretas; `Robot` y `Enemigo` deben implementar `Presentarse` y `Atacar`.

### 4. Interfaces: ejemplo complementario
No se encontró ninguna interfaz implementada en el código entregado. Una interfaz define un contrato que clases distintas pueden implementar sin exigir que compartan una clase base.

Ejemplo complementario:
```csharp
interface IAnalizable
{
    string ObtenerInforme();
}

class RegistroZona : IAnalizable
{
    public string ObtenerInforme()
    {
        return "Informe de la zona";
    }
}
```
Este ejemplo es didáctico y no forma parte del código actual de NEXUS.

### 5. Herencia, composición e interfaces
- Herencia: relación “es un”; `Robot` es una `Entidad`.
- Composición/contención: relación “tiene un”; `JuegoNexus` mantiene un inventario y una misión.
- Implementación de interfaz: relación de cumplimiento de contrato; una clase promete proporcionar los miembros de una interfaz.

## IV. Colecciones y LINQ

### 1. `List<T>` en NEXUS
El código declara `private List<Objeto> objetos = new List<Objeto>();` dentro de `Inventario` y `private List<Zona> zonas = new List<Zona>();` en `JuegoNexus`.
`List<T>` es una colección genérica que almacena elementos de un tipo definido. En `Inventario`, `Agregar` inserta objetos, `Obtener` valida un índice, `Eliminar` y `Consumir` retiran elementos, y `Mostrar` recorre la lista con un `for`.

### 2. Recorrido tradicional
`Inventario.Contiene` utiliza `foreach` y compara el nombre de cada objeto, ignorando mayúsculas y minúsculas mediante `StringComparison.OrdinalIgnoreCase`. Es una búsqueda lineal: en el peor caso revisa todos los elementos.

### 3. LINQ: no está implementado en el código recibido
No se encontraron llamadas a `Where`, `Select`, `OrderBy` ni expresiones lambda en `Program.cs`. Para estudiar el concepto, este ejemplo complementario podría filtrar los objetos que contienen “energia” en su nombre:
```csharp
using System.Linq;

// Ejemplo complementario; requiere que la colección esté disponible.
var resultados = objetos
    .Where(o => o.Nombre.IndexOf("energia",
        StringComparison.OrdinalIgnoreCase) >= 0)
    .OrderBy(o => o.Nombre)
    .Select(o => o.Nombre)
    .ToList();
```
`Where` filtra; `OrderBy` ordena; `Select` transforma cada objeto en su nombre; `ToList` materializa los resultados. La lambda `o => ...` expresa una función breve aplicada a cada elemento.

### 4. LINQ frente a recorridos tradicionales
Un recorrido `foreach` puede expresar el filtro paso a paso y es útil para depurar. LINQ suele hacer la intención más compacta y encadenable, pero no elimina la necesidad de comprender el algoritmo ni garantiza por sí solo un mejor rendimiento.

## V. Análisis del funcionamiento

### 1. Flujograma principal
El flujograma en `docs/diagramas.mmd` sigue el inicio desde `Program.Main`, la creación de `JuegoNexus`, la creación del cadete, el bucle principal y la salida por misión completada, muerte o abandono.

### 2. Seguimiento del estado de un objeto
Estado inicial al crear un cadete:
- Salud = 100
- Ataque = 20
- Energía = 70
- Experiencia = 0
- Escudos = 0

Si recibe 11 puntos de daño sin escudo, `Personaje.RecibirDanio` calcula `Math.Max(0, 100 - 11)`, por lo que la salud queda en 89.
Si después tiene un escudo y recibe 11 de daño, `Cadete.RecibirDanio` calcula `(11 + 1) / 2 = 6` con división entera, consume un escudo y la clase base reduce la salud en 6.

### 3. Predicción de código
```csharp
Cadete c = new Cadete("Ada");
c.GastarEnergia(10);
c.RecuperarEnergia(25);
```
Resultado: energía inicial 70; después de gastar 10 queda en 60; al recuperar 25 queda en 85. No supera el máximo de 100.

### 4. ¿Qué pasa si cambia una condición?
En `Mision.PuedeCompletar`, los tres objetivos se unen mediante `&&`. Si se cambiara accidentalmente por `||`, bastaría con cumplir uno solo de los objetivos para permitir la misión. Eso alteraría la dificultad y el sentido del proceso. La condición correcta requiere que los tres sean verdaderos.

### 5. Observaciones técnicas
- El código usa `Random` para seleccionar eventos y entidades, así que los recorridos no siempre producen la misma secuencia.
- `Desplazarse` valida que el destino sea numérico, esté dentro del mapa y sea adyacente.
- `RecibirDanio` limita la salud mínima a cero.
- La misión solo se completa si se investigó la anomalía, se encontró el núcleo y se sobrevivió a un encuentro; además, el cadete debe regresar a la zona de extracción.
- El proyecto concentra todas las clases en `Program.cs`. Separarlas en archivos podría mejorar la mantenibilidad, pero debe hacerse con pruebas para conservar el comportamiento.

## VI. Preparación para el examen: preguntas razonadas

### Pregunta 1 — POO
**¿Por qué `JuegoNexus` no debería administrar directamente cada detalle interno de salud, energía y escudos?**  
**Respuesta razonada:** porque `Cadete` encapsula esos datos y ofrece métodos como `GastarEnergia`, `RecuperarEnergia` y `RecibirDanio`. Esto concentra las reglas en la clase responsable y reduce modificaciones inválidas desde otras clases.

### Pregunta 2 — Clases y objetos
**¿Qué valores iniciales tiene `new Cadete("Ada")` y de dónde salen?**  
**Respuesta razonada:** `Cadete` asigna energía 70, experiencia 0 y escudos 0. La llamada `base(nombre, 100, 20)` establece nombre “Ada”, salud 100 y ataque 20 en `Personaje`.

### Pregunta 3 — Herencia y polimorfismo
**En `Entidad entidad = new Robot(); entidad.Atacar(cadete);`, ¿qué implementación se ejecuta?**  
**Respuesta razonada:** la implementación sobrescrita de `Robot.Atacar`, porque el método concreto se resuelve según el tipo real del objeto en tiempo de ejecución. La variable puede declararse como `Entidad`, pero la instancia es un `Robot`.

### Pregunta 4 — Diseño e interfaces
**¿Una interfaz sería lo mismo que `Entidad`? ¿Por qué?**  
**Respuesta razonada:** no. `Entidad` es una clase abstracta que hereda de `Personaje` y puede compartir estado e implementación. Una interfaz define un contrato que pueden implementar clases no relacionadas por herencia. NEXUS no tiene interfaces en el código revisado; la respuesta aplica al concepto y al ejemplo complementario.

### Pregunta 5 — Listas y LINQ
**¿Cómo funciona `Inventario.Contiene` y qué alternativa LINQ podría cumplir una tarea parecida?**  
**Respuesta razonada:** `Contiene` recorre `objetos` con `foreach` y compara nombres sin distinguir mayúsculas. Una alternativa sería `objetos.Any(o => o.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase))`, añadiendo `using System.Linq;`. Esta alternativa es complementaria, no está en el código actual.

### Pregunta 6 — Predicción de código
**Un cadete tiene 100 de salud y un escudo. Recibe 9 de daño. ¿Cuál será su salud y cuántos escudos quedarán?**  
**Respuesta razonada:** el daño se reduce a `(9 + 1) / 2 = 5`; la clase base deja la salud en 95. Se consume un escudo, por lo que quedan 0.

### Pregunta 7 — Modificación de condición
**¿Qué ocurriría si `PuedeCompletar` usara `||` en vez de `&&`?**  
**Respuesta razonada:** la misión podría completarse cuando solo uno de los tres objetivos estuviera registrado. Eso debilita la condición de victoria y produce un comportamiento diferente al diseño actual.

### Pregunta 8 — Colecciones
**¿Por qué `Inventario.Obtener` devuelve `null` si el índice es inválido?**  
**Respuesta razonada:** evita acceder fuera de los límites de la lista. El método verifica que el índice no sea negativo y sea menor que `objetos.Count`; los métodos que lo llaman deben comprobar si el resultado es `null` antes de usarlo.

## VII. Diagnóstico personal de aprendizaje — provisional

**Importante:** este apartado no sustituye el PROMPT ESPEJO final. La conversación disponible hasta este momento contiene principalmente solicitudes de ayuda y el envío del proyecto; todavía no ofrece suficientes respuestas propias del estudiante para evaluar todos los conceptos con rigor.

### 1. Fortalezas demostradas
- El estudiante organizó y compartió el archivo comprimido del proyecto para permitir una revisión basada en código real.
- Identificó que trabaja con C# y Visual Studio.
- Aún no hay evidencia suficiente para afirmar dominio independiente de los conceptos de POO.

### 2. Falencias observadas
No es correcto afirmar que existan errores conceptuales personales sin observar respuestas o explicaciones del estudiante. La principal limitación actual es la falta de evidencia directa de su razonamiento.

### 3. Diagnóstico H3 provisional
| Concepto | Estado de evidencia |
|---|---|
| POO | Evidencia insuficiente de explicación propia |
| Clases y objetos | Evidencia insuficiente |
| Constructores | Evidencia insuficiente |
| Encapsulamiento | Evidencia insuficiente |
| Herencia | Evidencia insuficiente |
| Polimorfismo | Evidencia insuficiente |
| Interfaces | Evidencia insuficiente |
| Listas genéricas | Evidencia insuficiente |
| LINQ | Evidencia insuficiente |

Esta clasificación evalúa la evidencia disponible en la conversación, no la capacidad real del estudiante.

### 4. Forma de aprender
La entrega del código permite realizar análisis concreto. Para evaluar cómo contrasta resultados y corrige errores, hará falta observar al estudiante resolviendo ejercicios y explicando sus decisiones.

### 5. Cinco prioridades y ejercicios
1. **Clases y constructores:** dibuja el estado de un `Cadete` recién creado y explica de dónde sale cada valor.
2. **Encapsulamiento:** explica por qué `Energia` tiene `private set` y qué métodos modifican su valor.
3. **Herencia y polimorfismo:** predice qué ocurre cuando un `Robot` recibe daño y cuándo se llama a `base.RecibirDanio`.
4. **Listas:** simula `Agregar`, `Obtener`, `Eliminar` y `Contiene` con tres objetos.
5. **LINQ:** escribe una consulta que filtre y ordene objetos; explica qué hace cada operador sin ayuda.

### 6. Conclusión provisional
El código permite estudiar una jerarquía de clases, encapsulamiento, clases abstractas, sobrescritura, listas genéricas y control de flujo. No se observan interfaces ni LINQ en la implementación revisada, por lo que deben estudiarse con ejemplos complementarios. Para concluir qué conocimientos domina personalmente el estudiante, es necesario que responda ejercicios sin recibir primero la solución.

**Pendiente:** cuando se complete el trabajo de aprendizaje, ejecutar el PROMPT ESPEJO exacto solicitado por la consigna y reemplazar este diagnóstico provisional por el resultado íntegro, sin atribuir al estudiante respuestas generadas por la IA.
